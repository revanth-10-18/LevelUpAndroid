package com.levelup.productivity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.min

private val Bg = Color(0xFF10121B)
private val Panel = Color(0xFF202132)
private val Panel2 = Color(0xFF28243B)
private val Purple = Color(0xFFA78BFA)
private val Mint = Color(0xFF6EE7B7)
private val Muted = Color(0xFFAAAAC0)
private val White = Color(0xFFF5F3FF)

data class GoalTask(
    val id: Long,
    val title: String,
    val category: String,
    val done: Boolean,
    val date: String
)

data class DailyQuote(val text: String, val by: String, val source: String)

private val quotes = listOf(
    DailyQuote("Hard work is worthless for those that don't believe in themselves.", "Naruto Uzumaki", "Naruto"),
    DailyQuote("It's not about how hard you hit. It's about how hard you can get hit and keep moving forward.", "Rocky Balboa", "Rocky"),
    DailyQuote("A lesson without pain is meaningless.", "Edward Elric", "Fullmetal Alchemist"),
    DailyQuote("Sometimes you have to take a leap of faith first. The trust part comes later.", "Michael Scofield", "Prison Break"),
    DailyQuote("The moment you think of giving up, think of the reason why you held on so long.", "Natsu Dragneel", "Fairy Tail"),
    DailyQuote("Whatever you lose, you'll find it again. But what you throw away you'll never get back.", "Kenshin Himura", "Rurouni Kenshin"),
    DailyQuote("It does not do to dwell on dreams and forget to live.", "Albus Dumbledore", "Harry Potter")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LevelUpApp() }
    }
}

@Composable
fun LevelUpApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("level_up_store", android.content.Context.MODE_PRIVATE) }
    val today = LocalDate.now()
    var selectedTab by remember { mutableStateOf("Today") }
    var selectedDate by remember { mutableStateOf(today) }
    var shownMonth by remember { mutableStateOf(YearMonth.from(today)) }
    var taskTitle by remember { mutableStateOf("") }
    var taskCategory by remember { mutableStateOf("Personal") }
    var filter by remember { mutableStateOf("All") }
    var dailyGoal by remember { mutableStateOf(prefs.getString("daily_goal", "Become 1% better every day") ?: "") }
    var goalInput by remember { mutableStateOf("") }
    var quoteRefresh by remember { mutableIntStateOf(0) }

    var tasks by remember {
        mutableStateOf(loadTasks(prefs).ifEmpty {
            listOf(
                GoalTask(1, "Study for 2 focused hours", "Study", false, today.toString()),
                GoalTask(2, "Solve one coding problem", "Coding", false, today.toString()),
                GoalTask(3, "Exercise for 20 minutes", "Health", false, today.toString()),
                GoalTask(4, "Read or learn something new", "Growth", false, today.toString())
            ).also { saveTasks(prefs, it) }
        })
    }
    var completedDays by remember { mutableStateOf(loadDays(prefs)) }

    fun updateTasks(newTasks: List<GoalTask>) {
        tasks = newTasks
        saveTasks(prefs, newTasks)
    }
    fun updateDays(newDays: Set<String>) {
        completedDays = newDays
        saveDays(prefs, newDays)
    }

    val todaysTasks = tasks.filter { it.date == selectedDate.toString() }
    val finished = todaysTasks.count { it.done }
    val total = todaysTasks.size
    val progress = if (total == 0) 0f else finished.toFloat() / total
    val quote = quotes[(LocalDate.now().dayOfYear + quoteRefresh) % quotes.size]

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Mint, background = Bg, surface = Panel,
            onPrimary = Bg, onBackground = White, onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF171A27), contentColor = White) {
                    NavigationBarItem(
                        selected = selectedTab == "Today",
                        onClick = { selectedTab = "Today" },
                        icon = { Icon(Icons.Default.TaskAlt, null) },
                        label = { Text("Today") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == "Calendar",
                        onClick = { selectedTab = "Calendar" },
                        icon = { Icon(Icons.Default.CalendarMonth, null) },
                        label = { Text("Calendar") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == "Progress",
                        onClick = { selectedTab = "Progress" },
                        icon = { Icon(Icons.Default.Insights, null) },
                        label = { Text("Progress") }
                    )
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Purple),
                            contentAlignment = Alignment.Center
                        ) { Text("⚡", fontSize = 24.sp, color = Bg) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("LEVEL UP.", fontSize = 22.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.sp)
                            Text("YOUR LIFE. YOUR RULES.", fontSize = 10.sp, color = Muted, letterSpacing = 1.5.sp)
                        }
                        Surface(shape = CircleShape, color = Panel2) {
                            Text("🔥 ${completedDays.size}", Modifier.padding(horizontal = 12.dp, vertical = 9.dp), color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel2).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✦  DAILY INSPIRATION", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { quoteRefresh++ }) { Icon(Icons.Default.Refresh, "New quote", tint = Purple) }
                        }
                        Text("“${quote.text}”", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, lineHeight = 24.sp)
                        Text("— ${quote.by} · ${quote.source}", color = Muted, fontSize = 12.sp)
                    }
                }
                item {
                    Text(selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")).uppercase(), color = Muted, fontSize = 11.sp)
                    Text(if (selectedDate == today) "Make today count." else "Make this day count.", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("You don't need to be perfect. Just keep showing up.", color = Muted, fontSize = 13.sp)
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("TASKS", "$finished/$total", "completed", progress, Modifier.weight(1f))
                        StatCard("CHECK-INS", "${completedDays.size}", "days completed", null, Modifier.weight(1f))
                    }
                }

                if (selectedTab == "Today") {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Today's missions", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("Small wins lead to big changes.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("All", "Pending", "Completed").forEach { option ->
                                FilterChip(
                                    selected = filter == option,
                                    onClick = { filter = option },
                                    label = { Text(option) }
                                )
                            }
                        }
                    }
                    item {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = taskTitle, onValueChange = { taskTitle = it },
                                label = { Text("Add a task") }, modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                var catExpanded by remember { mutableStateOf(false) }
                                Box {
                                    OutlinedButton(onClick = { catExpanded = true }) { Text(taskCategory) }
                                    DropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                                        listOf("Personal", "Study", "Coding", "Health", "Growth").forEach {
                                            DropdownMenuItem(text = { Text(it) }, onClick = { taskCategory = it; catExpanded = false })
                                        }
                                    }
                                }
                                Button(
                                    onClick = {
                                        if (taskTitle.isNotBlank()) {
                                            updateTasks(tasks + GoalTask(System.currentTimeMillis(), taskTitle.trim(), taskCategory, false, selectedDate.toString()))
                                            taskTitle = ""
                                        }
                                    }, modifier = Modifier.weight(1f)
                                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add task") }
                            }
                        }
                    }
                    val visible = todaysTasks.filter { filter == "All" || (filter == "Pending" && !it.done) || (filter == "Completed" && it.done) }
                    if (visible.isEmpty()) {
                        item { EmptyCard(if (todaysTasks.isEmpty()) "No tasks yet. Add your first mission!" else "Nothing in this filter. Nice work!") }
                    }
                    items(visible, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            onToggle = { updateTasks(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) },
                            onDelete = { updateTasks(tasks.filterNot { it.id == task.id }) }
                        )
                    }
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel2).padding(16.dp)) {
                            Text("◎  MY GOAL OF THE DAY", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(dailyGoal, color = White, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(value = goalInput, onValueChange = { goalInput = it }, label = { Text("Set a new daily goal") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Button(onClick = {
                                if (goalInput.isNotBlank()) {
                                    dailyGoal = goalInput.trim()
                                    prefs.edit().putString("daily_goal", dailyGoal).apply()
                                    goalInput = ""
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Update daily goal") }
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF202D2A)).padding(16.dp)) {
                            Icon(Icons.Default.EmojiEvents, null, tint = Mint)
                            Text(if (total > 0 && finished == total) "All missions cleared!" else "${
                                (progress * 100).toInt()
                            }% complete", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Mint)
                            Text(if (total > 0 && finished == total) "You kept every promise you made to yourself today." else "Finish the next mission to level up.", color = Muted)
                        }
                    }
                } else if (selectedTab == "Calendar") {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = { shownMonth = shownMonth.minusMonths(1) }) { Text("‹") }
                            Text(shownMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { shownMonth = shownMonth.plusMonths(1) }) { Text("›") }
                        }
                    }
                    item {
                        CalendarGrid(
                            month = shownMonth,
                            selected = selectedDate,
                            completedDays = completedDays,
                            onSelect = { selectedDate = it }
                        )
                    }
                    item {
                        val isDone = selectedDate.toString() in completedDays
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp)) {
                            Text(selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(if (isDone) "You showed up. That's a win." else "Your next opportunity to build consistency is here.", color = Muted)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { updateDays(if (isDone) completedDays - selectedDate.toString() else completedDays + selectedDate.toString()) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (isDone) "Undo completed day" else "✓  Mark day complete") }
                            Spacer(Modifier.height(8.dp))
                            Text("Daily check-ins are separate from individual task completion.", color = Muted, fontSize = 11.sp)
                        }
                    }
                } else {
                    item { Text("Your progress", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                    item { Text("Measure your actions, celebrate your wins, and keep going.", color = Muted, fontSize = 13.sp) }
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TASK COMPLETION", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            DonutChart(finished, total - finished)
                            Text("$finished of $total tasks · ${(progress * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    item {
                        val lastDays = (6 downTo 0).map { today.minusDays(it.toLong()) }
                        val values = lastDays.map { date -> tasks.count { it.date == date.toString() && it.done } }
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp)) {
                            Text("Last 7 days · tasks completed", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(14.dp))
                            BarChart(labels = lastDays.map { it.dayOfWeek.name.take(3) }, values = values)
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel2).padding(16.dp)) {
                            Text("YOUR CURRENT STATS", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                SmallStat("Tasks finished", tasks.count { it.done }.toString())
                                SmallStat("Check-in days", completedDays.size.toString())
                                SmallStat("Tasks total", tasks.size.toString())
                            }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("ONE DAY. ONE STEP. ONE LEVEL UP.", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                    Text("Your progress is stored on this device.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, subtitle: String, progress: Float?, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(value, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
        if (progress != null) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = Purple, trackColor = Color(0xFF414058))
        }
    }
}

@Composable
private fun TaskCard(task: GoalTask, onToggle: () -> Unit, onDelete: () -> Unit) {
    val animatedColor by animateColorAsState(if (task.done) Color(0xFF1D2B2A) else Panel, label = "taskColor")
    val strike by animateFloatAsState(if (task.done) 1f else 0f, label = "strike")
    AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically { it / 5 }, exit = fadeOut()) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(animatedColor).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(if (task.done) Mint else Color(0xFF333449))
                    .clickable { onToggle() },
                contentAlignment = Alignment.Center
            ) {
                if (task.done) Icon(Icons.Default.Check, null, tint = Bg, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).clickable { onToggle() }) {
                Box {
                    Text(task.title, color = if (task.done) Muted else White, fontWeight = FontWeight.Medium, textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None)
                    if (strike > 0f) {
                        Canvas(Modifier.fillMaxWidth().height(24.dp)) {
                            drawLine(Mint.copy(alpha = strike * 0.75f), Offset(0f, size.height / 2), Offset(size.width * strike, size.height / 2), strokeWidth = 1.5.dp.toPx(), cap = StrokeCap.Round)
                        }
                    }
                }
                Text("${task.category} · ${if (task.done) "Completed ✓" else "Still to do"}", color = if (task.done) Mint else Muted, fontSize = 11.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Muted) }
        }
    }
}

@Composable
private fun CalendarGrid(month: YearMonth, selected: LocalDate, completedDays: Set<String>, onSelect: (LocalDate) -> Unit) {
    val firstOffset = month.atDay(1).dayOfWeek.value % 7
    val days = month.lengthOfMonth()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(12.dp)) {
        Row(Modifier.fillMaxWidth()) {
            listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                Text(it, color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
        Spacer(Modifier.height(8.dp))
        for (week in 0 until ((firstOffset + days + 6) / 7)) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..6) {
                    val day = week * 7 + col - firstOffset + 1
                    Box(Modifier.weight(1f).aspectRatio(0.9f).padding(2.dp), contentAlignment = Alignment.Center) {
                        if (day in 1..days) {
                            val date = month.atDay(day)
                            val done = date.toString() in completedDays
                            val isSelected = date == selected
                            Box(
                                Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp))
                                    .background(if (done) Purple else if (isSelected) Panel2 else Color.Transparent)
                                    .clickable { onSelect(date) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (done) Icon(Icons.Default.Check, null, tint = Bg, modifier = Modifier.size(18.dp))
                                else Text("$day", color = if (isSelected) Purple else White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DonutChart(done: Int, remaining: Int) {
    val total = (done + remaining).coerceAtLeast(1)
    val sweep = 360f * done / total
    Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(12.dp)) {
            drawArc(Color(0xFF414058), -90f, 360f, false, style = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round))
            if (done > 0) drawArc(Purple, -90f, sweep, false, style = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(100 * done / total)}%", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = White)
            Text("complete", color = Muted, fontSize = 12.sp)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        LegendDot(Purple, "Completed $done")
        LegendDot(Color(0xFF414058), "Remaining $remaining")
    }
}

@Composable
private fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Text(text, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun BarChart(labels: List<String>, values: List<Int>) {
    val maxValue = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        labels.forEachIndexed { index, label ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                Text("${values[index]}", color = White, fontSize = 11.sp)
                Spacer(Modifier.height(5.dp))
                val barHeight = (values[index].toFloat() / maxValue * 88).coerceAtLeast(if (values[index] > 0) 8f else 3f)
                Box(Modifier.width(22.dp).height(barHeight.dp).clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)).background(Purple))
                Spacer(Modifier.height(7.dp))
                Text(label, color = Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun SmallStat(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(value, color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("✦", color = Purple, fontSize = 28.sp)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Muted)
    }
}

private fun loadTasks(prefs: android.content.SharedPreferences): List<GoalTask> {
    return try {
        val array = JSONArray(prefs.getString("tasks_json", "[]"))
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            GoalTask(obj.getLong("id"), obj.getString("title"), obj.getString("category"), obj.getBoolean("done"), obj.getString("date"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveTasks(prefs: android.content.SharedPreferences, tasks: List<GoalTask>) {
    val array = JSONArray()
    tasks.forEach { task ->
        array.put(JSONObject().apply {
            put("id", task.id); put("title", task.title); put("category", task.category)
            put("done", task.done); put("date", task.date)
        })
    }
    prefs.edit().putString("tasks_json", array.toString()).apply()
}

private fun loadDays(prefs: android.content.SharedPreferences): Set<String> {
    return try {
        val array = JSONArray(prefs.getString("completed_days", "[]"))
        (0 until array.length()).map { array.getString(it) }.toSet()
    } catch (_: Exception) { emptySet() }
}

private fun saveDays(prefs: android.content.SharedPreferences, days: Set<String>) {
    val array = JSONArray()
    days.sorted().forEach { array.put(it) }
    prefs.edit().putString("completed_days", array.toString()).apply()
}
