# Level Up — Android productivity app

A native Android app built with Kotlin + Jetpack Compose. Features:
- Daily tasks with categories, animated completion/strike-through, filters, and delete.
- Calendar with manual completed-day check-ins.
- Progress screen with a donut/pie-style chart and 7-day bar chart.
- Daily motivational quote rotation.
- Daily goal.
- Local persistence using SharedPreferences (tasks, completed days, daily goal).

## Build an APK (Windows)

1. Install **Android Studio** from https://developer.android.com/studio
2. Open Android Studio → **Open** → choose the `LevelUpAndroid` folder (the folder containing `settings.gradle.kts`).
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and JDK 17.
4. For a debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build finishes, click **locate** in the notification. The APK is usually:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and open it. If prompted, allow installing unknown apps for the app you used to open the APK. Only install APKs you built or trust.

## Build a release APK

For a release APK, use **Build → Generate Signed Bundle / APK → APK**, create and safely store your own signing key, then follow the wizard. Keep the key private; you need it for future updates.

## Notes

- The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35 and Java 17.
- The app stores data on the device only. Clearing app data or uninstalling may erase it. There is no cloud sync or account system.
- The sample tasks are added only on a fresh install when no saved tasks exist.
- Quotes are short excerpts attributed to fictional characters; quote wording and attribution may vary by edition.
- The app chooses a daily quote using the day of year; use the refresh button to cycle through quotes.
